// Code goes here
(function() 
{

    var app = angular.module("githubViewer", []);
    
    // Controller for the main page
    var MainController = function($scope, $http) 
    {
        // Function for handling the user promise object from http get request
        var onUserComplete = function(response)
        {
            // Store JSON data into $scope, attach to user model for view
            $scope.user = response.data;
        };
        
        // If the controller returns an error, print it out
        var onError = function(reason)
        {
            $scope.error = "Could not fetch the user";
        };
        
        // Get request to retrieve user data from GitHub site
        $http.get("https://api.github.com/users/robconery")
            .then(onUserComplete, onError);
        
        // Models bound to the $scope here:
        $scope.message = "Hello, Internet person!";
    };

    // This tells Angular to use MainController function when "MainController" is needed
    app.controller("MainController", MainController);

}());